﻿'use strict';
app.controller('qaSecurityController', ['$scope', '$location', 'qaService', 'authService', '$routeParams', '$rootScope', '$window', function ($scope, $location, qaService, authService, $routeParams, $rootScope, $window) {
    $scope.isNew = true;
    $scope.isEditable = true;
    $scope.isLockVisible = false;
    $scope.isContentVisible = false;
    $scope.isFullScreen = false;
    var detector = new MobileDetect(window.navigator.userAgent);

    //if (detector.mobile() && !detector.tablet())
    $scope.isFullScreen = false;

    $scope.entity = {
        Id: -1,
    };

    $scope.followUpEntity = {
        Type: 5,
    }

    $scope.optReason = [],


        ////////////////////////
        $scope.popup_add_visible = false;
    $scope.popup_height = $(window).height() - 100;
    $scope.popup_width = 1500;
    $scope.popup_add_title = 'Security Hazard Report Form';
    $scope.popup_instance = null;

    $scope.popup_add = {


        showTitle: true,

        toolbarItems: [

            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Referre', onClick: function (e) {

                        $rootScope.$broadcast('InitQAEmployee', { Type: $scope.followUpEntity.Type, Id: $scope.entity.Id });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Action', onClick: function (e) {

                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'success', text: 'Accept', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.acceptQA($scope.followUpEntity).then(function (response) {
                            General.ShowNotify(Config.Text_QAAccept, 'success');

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'danger', text: 'Reject', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.rejectQA($scope.followUpEntity).then(function (response) {
                            General.ShowNotify(Config.Text_QAAccept, 'success');

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'after', options: {
                    type: 'danger', text: 'Close', icon: 'remove', onClick: function (e) {
                        $scope.popup_add_visible = false;

                    }
                }, toolbar: 'bottom'
            }
        ],

        visible: false,
        dragEnabled: true,
        closeOnOutsideClick: false,
        onShowing: function (e) {
            $rootScope.IsRootSyncEnabled = false;
            $scope.popup_instance.repaint();


        },
        onShown: function (e) {

            if ($scope.isNew) {
                $scope.isContentVisible = true;
            }
            if ($scope.tempData != null)
                $scope.bind();





        },
        onHiding: function () {
            $rootScope.IsRootSyncEnabled = true;
            //$scope.clearEntity();
            $scope.entity = {
                Id: -1,

            };


            $scope.popup_add_visible = false;
            $rootScope.$broadcast('onQASecurityHide', null);


        },
        onContentReady: function (e) {
            if (!$scope.popup_instance)
                $scope.popup_instance = e.component;


        },
        // fullScreen:false,
        bindingOptions: {
            visible: 'popup_add_visible',
            fullScreen: 'isFullScreen',
            title: 'popup_add_title',
            height: 'popup_height',
            width: 'popup_width',
            'toolbarItems[2].visible': 'isSettled',
            'toolbarItems[3].visible': 'isSettled',

        }
    };



    /////////////////////////////////
    $scope.fill = function (data) {
        console.log(data.ReasonId);


        $scope.entity = data;
        $.each($scope.shrReason, function (_i, _d) {
            if (_d.Id == data.ReasonId)
                _d.checked = true;
        });





    };
    $scope.isLockVisible = false;
    $scope.bind = function () {

        qaService.getSHRReason().then(function (res) {
            $scope.shrReason = res.Data
            qaService.getSHRById($scope.followUpEntity.Id).then(function (res) {
                if (res.Data.Id != null) {
                    $scope.fill(res.Data);
                }
                else {
                    $scope.entity.FlightNumber = res.Data.FlightNumber;
                    $scope.entity.Route = res.Data.Route;
                    $scope.entity.Register = res.Data.Register;
                }

            });
        });

        qaService.getReferredList($scope.followUpEntity.EmployeeId, $scope.followUpEntity.Type, $scope.followUpEntity.Id).then(function (response) {
            $scope.referred_list_ds = response.Data;
        });



    };
    ////////////////////////////////
    $scope.scroll_qaSecurity_height = $scope.popup_height - 115;
    $scope.scroll_qaSecurity = {
        width: 900,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_qaSecurity_height'
        }

    };


    $scope.scroll_referre_height = $scope.popup_height - 115;
    $scope.scroll_referre = {
        width: 590,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_referre_height'
        }

    };

    /////////////////////////////////


    $scope.chkReason = function (index) {

        $.each($scope.shrReason, function (_i, _d) {
            if (_d.Title.includes('سایر')) {
                if (_d.checked)
                    $scope.showOther = true;
                else
                    $scope.showOther = false;
            }
        });

        $scope.shrReason[index].checked = !$scope.shrReason[index].checked;
        $scope.entity.ReasonId = $scope.shrReason[index].Id;
    }



    $scope.txt_reportDate = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.DateReport',
        }
    }

    $scope.txt_hazardDate = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'yyyy-MM-dd HH:mm',
        type: 'datetime',
        bindingOptions: {
            value: 'entity.DateTimeHazard',
        }
    }
    $scope.txt_area = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Place',
        }
    }

    $scope.txt_route = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Route',
        }
    }

    $scope.txt_eventOther = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.ReasonDescription',
        }
    }

    $scope.txt_register = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Register',
        }
    }

    $scope.txt_flightNumber = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.FlightNumber',
        }
    }

    $scope.txt_camera = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Camera',
        }
    }

    $scope.txt_carryingBox = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.CarryingBox',
        }
    }

    $scope.txt_comail = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Comail',
        }
    }


    $scope.txt_handRocket = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.HandRocket',
        }
    }

    $scope.txt_injuryOccuring = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.InjuryOccuring',
        }
    }

    $scope.txt_other = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Other',
        }
    }

    $scope.txt_equipmentDescription = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.EquipmentDescription',
        }
    }

    $scope.txt_injuryDescription = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.InjuryDescription',
        }
    }

    $scope.txt_workBreak = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.WorkBreak',
        }
    }

    $scope.txt_workBreakPeriod = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.WorkBreakPeriod',
        }
    }

    $scope.txt_preventiveActions = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.PreventiveActions',
        }
    }




    ////////////////////////////////
    $scope.referred_list_columns = [
        { dataField: 'ReferredName', caption: 'Name', allowResizing: true, alignment: 'center', dataType: 'number', allowEditing: false, width: 350 },
        { dataField: 'DateStatus', caption: 'Date', allowResizing: true, alignment: 'center', dataType: 'date', allowEditing: false, width: 240 },
    ]
    $scope.referred_list = {
        keyExpr: 'ReferredId',
        parentIdExpr: 'ReferrerId',
        columns: $scope.referred_list_columns,
        noDataText: '',
        bindingOptions: {
            dataSource: 'referred_list_ds',

        }
    }

    //////////////////////////////////

    $scope.$on('InitQASecurity', function (event, prms) {


        $scope.tempData = null;
        $scope.tempData = prms;

        $scope.followUpEntity.Category = $scope.tempData.Category;
        $scope.followUpEntity.Id = $scope.tempData.Id;
        $scope.followUpEntity.Type = $scope.tempData.Type;
        $scope.followUpEntity.EmployeeId = $scope.tempData.EmployeeId;

        $scope.isNotDetermined = $scope.tempData.isNotDetermined;

        if ($scope.tempData.Status != null)
            $scope.isSettled = false
        $scope.popup_add_visible = true;
    });


}]);


