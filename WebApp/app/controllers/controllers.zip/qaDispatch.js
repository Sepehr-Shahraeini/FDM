﻿'use strict';
app.controller('qaDispatchController', ['$scope', '$location', 'qaService', 'authService', '$routeParams', '$rootScope', '$window', function ($scope, $location, qaService, authService, $routeParams, $rootScope, $window) {
    $scope.isNew = true;
    $scope.isEditable = true;
    $scope.isLockVisible = false;
    $scope.isContentVisible = false;
    $scope.isFullScreen = false;
    var detector = new MobileDetect(window.navigator.userAgent);

    //if (detector.mobile() && !detector.tablet())
    $scope.isFullScreen = false;

    $scope.entity = {
        Id: -1,
    };

    $scope.followUpEntity = {
        Type: 6,
    }


    $scope.optOPCatagory = [];
    $scope.optDISCatagory = [];


    ////////////////////////
    $scope.popup_add_visible = false;
    $scope.popup_height = $(window).height() - 100;
    $scope.popup_width = 1500;
    $scope.popup_add_title = 'Dispatch Hazard Report';
    $scope.popup_instance = null;

    $scope.popup_add = {


        showTitle: true,

        toolbarItems: [
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Referre', onClick: function (e) {

                        $rootScope.$broadcast('InitQAEmployee', { Type: $scope.followUpEntity.Type, Id: $scope.tempData.Id });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Action', onClick: function (e) {

                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'success', text: 'Accept', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.acceptQA($scope.followUpEntity).then(function (response) {
                            if (response.IsSuccess == true)
                                General.ShowNotify(Config.Text_QAAccept, 'success');
                            console.log(response);
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'danger', text: 'Reject', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.rejectQA($scope.followUpEntity).then(function (response) {
                            General.ShowNotify(Config.Text_QAAccept, 'success');

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'after', options: {
                    type: 'danger', text: 'Close', icon: 'remove', onClick: function (e) {
                        $scope.popup_add_visible = false;

                    }
                }, toolbar: 'bottom'
            }
        ],

        visible: false,
        dragEnabled: true,
        closeOnOutsideClick: false,
        onShowing: function (e) {
            $rootScope.IsRootSyncEnabled = false;
            $scope.popup_instance.repaint();


        },
        onShown: function (e) {

            if ($scope.isNew) {
                $scope.isContentVisible = true;
            }
            if ($scope.tempData != null)
                $scope.bind();





        },
        onHiding: function () {
            $rootScope.IsRootSyncEnabled = true;
            $scope.entity = {
                Id: -1,

            };


            $scope.popup_add_visible = false;
            $rootScope.$broadcast('onQADispatchHide', null);


        },
        onContentReady: function (e) {
            if (!$scope.popup_instance)
                $scope.popup_instance = e.component;


        },
        // fullScreen:false,
        bindingOptions: {
            visible: 'popup_add_visible',
            fullScreen: 'isFullScreen',
            title: 'popup_add_title',
            height: 'popup_height',
            width: 'popup_width',
            'toolbarItems[2].visible': 'isSettled',
            'toolbarItems[3].visible': 'isSettled',

        }
    };



    /////////////////////////////////
    $scope.fill = function (data) {
        console.log(data.ReasonId);

        console.log($scope.opCatagory);
        $scope.entity = data;
        $.each($scope.opCatagory, function (_i, _d) {

            if (_d.Id == data.CatagoryId)
                _d.checked = true;
        });

        console.log($scope.opCatagory);
        $.each($scope.disCatagory, function (_i, _d) {
            if (_d.Id == data.CatagoryId)
                _d.checked = true;
        });





    };
    $scope.isLockVisible = false;
    $scope.bind = function () {

        qaService.getOPCatagory().then(function (res) {
            $scope.opCatagory = res.Data

        });
        qaService.getDISCatagory().then(function (res) {
            $scope.disCatagory = res.Data
            console.log($scope.disCatagory);
            qaService.getDHRById($scope.followUpEntity.Id).then(function (res) {

                console.log(res);
                if (res.Data.Id != null) {
                    $scope.fill(res.Data);
                }
                else {
                    $scope.entity.FlightNumber = res.Data.FlightNumber;
                    $scope.entity.Route = res.Data.Route;
                    $scope.entity.Register = res.Data.Register;
                }

            });
        });

        qaService.getReferredList($scope.followUpEntity.EmployeeId, $scope.followUpEntity.Type, $scope.followUpEntity.Id).then(function (response) {
            $scope.referred_list_ds = response.Data;
        });


    };
    ////////////////////////////////
    $scope.scroll_qaDispatch_height = $scope.popup_height - 115;
    $scope.scroll_qaDispatch = {
        width: 900,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_qaDispatch_height'
        }

    };


    $scope.scroll_referre_height = $scope.popup_height - 115;
    $scope.scroll_referre = {
        width: 590,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_referre_height'
        }

    };

    /////////////////////////////////


    $scope.chkOPCatagory = function (index) {
        $scope.opCatagory[index].checked = !$scope.opCatagory[index].checked;
        $scope.entity.OPCatagoryId = $scope.opCatagory[index].Id;
    }

    $scope.chkDISCatagory = function (index) {

        $scope.disCatagory[index].checked = !$scope.disCatagory[index].checked;
        $scope.entity.DISCatagoryId = $scope.opCatagory[index].Id;
    }



    $scope.txt_dateReport = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.DateReport',
        }
    }

    $scope.ds_type = [
        { id: 0, title: "In Flight Operation" },
        { id: 1, title: "In Flight Dispatch Process" }
    ];

    $scope.sb_occuranceType = {
        hoverStateEnabled: false,
        dataSource: $scope.ds_type,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.Type',
        }
    }

    $scope.txt_hazardDate = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'yyyy-MM-dd HH:mm',
        type: 'datetime',
        bindingOptions: {
            value: 'entity.DateTimeHazard',
        }
    }

    $scope.txt_opEventDate = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'yyyy-MM-dd HH:mm',
        type: 'datetime',
        bindingOptions: {
            value: 'entity.OPDateTimeEvent',
        }
    }

    $scope.txt_opReportTime = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'HH:mm',
        type: 'time',
        bindingOptions: {
            value: 'entity.DateTimeHazard',
        }
    }

    $scope.txt_opReporterName = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OPReportedBy',
        }
    }

  
    $scope.txt_ActionTaken = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Remarks',
        }
    }

    $scope.txt_eventLocation = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OPLocation',
        }
    }

    $scope.ds_status = [
        { id: 0, title: "NO" },
        { id: 1, title: "YES" }
    ];

    $scope.sb_fltCancelled = {
        hoverStateEnabled: false,
        dataSource: $scope.ds_status,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity',
        }
    }

    $scope.txt_fltCancelledTime = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'HH:mm',
        type: 'time',
        bindingOptions: {
            value: 'entity',
        }
    }


    $scope.sb_acChanged = {
        hoverStateEnabled: false,
        dataSource: $scope.ds_status,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity',
        }
    }

    $scope.txt_acChangeTime = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'HH:mm',
        type: 'time',
        bindingOptions: {
            value: 'entity',
        }
    }


    $scope.sb_crewChanged = {
        hoverStateEnabled: false,
        dataSource: $scope.ds_status,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity',
        }
    }

    $scope.txt_crewChangeTime = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'HH:mm',
        type: 'time',
        bindingOptions: {
            value: 'entity',
        }
    }


    $scope.sb_fltPerformed = {
        hoverStateEnabled: false,
        dataSource: $scope.ds_status,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity',
        }
    }

    $scope.txt_fltPerformedTime = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'HH:mm',
        type: 'time',
        bindingOptions: {
            value: 'entity',
        }
    }

    $scope.txt_opEventSummery = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OPSummary',
        }
    }




    ////////////////////////////////
    $scope.referred_list_columns = [
        { dataField: 'ReferredName', caption: 'Name', allowResizing: true, alignment: 'center', dataType: 'number', allowEditing: false, width: 350 },
        { dataField: 'DateStatus', caption: 'Date', allowResizing: true, alignment: 'center', dataType: 'date', allowEditing: false, width: 240 },
    ]
    $scope.referred_list = {
        keyExpr: 'ReferredId',
        parentIdExpr: 'ReferrerId',
        columns: $scope.referred_list_columns,
        noDataText: '',
        bindingOptions: {
            dataSource: 'referred_list_ds',

        }
    }

    /////////////////////////////
    $scope.$on('InitQADispatch', function (event, prms) {


        $scope.tempData = null;
        $scope.tempData = prms;

        $scope.followUpEntity.Category = $scope.tempData.Category;
        $scope.followUpEntity.Id = $scope.tempData.Id;
        $scope.followUpEntity.Type = $scope.tempData.Type;
        $scope.followUpEntity.EmployeeId = $scope.tempData.EmployeeId;

        $scope.isNotDetermined = $scope.tempData.isNotDetermined;

        if ($scope.tempData.Status != null)
            $scope.isSettled = false
        $scope.popup_add_visible = true;
    });



}]);


