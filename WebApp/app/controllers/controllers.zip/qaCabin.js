﻿'use strict';
app.controller('qaCabinController', ['$scope', '$location', 'qaService', 'authService', '$routeParams', '$rootScope', '$window', function ($scope, $location, qaService, authService, $routeParams, $rootScope, $window) {
    $scope.isNew = true;
    $scope.isEditable = false;
    $scope.isLockVisible = false;
    $scope.isContentVisible = false;
    $scope.isFullScreen = false;
    var detector = new MobileDetect(window.navigator.userAgent);

    //if (detector.mobile() && !detector.tablet())
    $scope.isFullScreen = false;

    $scope.entity = {
        Id: -1,
        EventTitleIds: [],
    };

    $scope.followUpEntity = {
        Type: 0,
    }

    $scope.fpoptions = [];
    $scope.etoptions = [];




    ////////////////////////

    $scope.popup_add_visible = false;
    $scope.popup_height = $(window).height() - 100;
    $scope.popup_width = 1500;
    $scope.popup_add_title = 'Cabin Safety Report (C.S.R)';
    $scope.popup_instance = null;

    $scope.popup_add = {


        showTitle: true,

        toolbarItems: [

            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Referre', onClick: function (e) {

                        $rootScope.$broadcast('InitQAEmployee', { Type: $scope.followUpEntity.Type, Id: $scope.tempData.Id });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Action', onClick: function (e) {

                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'success', text: 'Accept', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.acceptQA($scope.followUpEntity).then(function (response) {
                            General.ShowNotify(Config.Text_QAAccept, 'success');

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();
                              
                            }

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'danger', text: 'Reject', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.rejectQA($scope.followUpEntity).then(function (response) {
                            General.ShowNotify(Config.Text_QAAccept, 'success');

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },

            {
                widget: 'dxButton', location: 'after', options: {
                    type: 'danger', text: 'Close', icon: 'remove', onClick: function (e) {
                        $scope.popup_add_visible = false;
                    }
                }, toolbar: 'bottom'
            }

        ],

        visible: false,
        dragEnabled: true,
        closeOnOutsideClick: false,
        onShowing: function (e) {
            $rootScope.IsRootSyncEnabled = false;
            $scope.popup_instance.repaint();


        },
        onShown: function (e) {

            if ($scope.isNew) {
                $scope.isContentVisible = true;
            }
            if ($scope.tempData != null)
                $scope.bind();





        },
        onHiding: function () {
            //$rootScope.IsRootSyncEnabled = true;
            //$scope.clearEntity();
            $scope.entity = {
                Id: -1,
                EventTitleIds: [],

            };
            $scope.fpoptions = [];
            $scope.etoptions = [];
            $scope.popup_add_visible = false;
            //$rootScope.$broadcast('onCabinHide', null);
        },
        onContentReady: function (e) {
            if (!$scope.popup_instance)
                $scope.popup_instance = e.component;

        },
        // fullScreen:false,
        bindingOptions: {
            visible: 'popup_add_visible',
            fullScreen: 'isFullScreen',
            title: 'popup_add_title',
            height: 'popup_height',
            width: 'popup_width',
            'toolbarItems[0].visible': 'isNotDetermined',
            'toolbarItems[1].visible': 'isNotDetermined',
            'toolbarItems[2].visible': 'isNotDetermined',
            'toolbarItems[3].visible': 'isNotDetermined',

        }
    };



    /////////////////////////////////
    $scope.fill = function (data) {
        $scope.entity = data.result;
        $scope.entity.EventTitleIds = [];
        $.each($scope.flightPhase, function (_i, _d) {
            if (_d.Id == data.result.PhaseId)
                _d.checked = true;
        });
        $.each(data.CSREvent, function (_i, _d) {
            $scope.etoptions[_d.EventTitleId] = true;
        });

    };
    $scope.isLockVisible = false;
    $scope.bind = function () {


        qaService.getEventTitle().then(function (res) {
            $scope.eventTitle = res.Data;

        });

        qaService.getFlightPhase().then(function (res) {
            $scope.flightPhase = res.Data;
            qaService.getCSRById($scope.followUpEntity.Id).then(function (res) {

                
                if (res.Data.result.Id != null) {
                    $scope.fill(res.Data);
                }
                else {
                    $scope.entity.FlightNumber = res.Data.result.FlightNumber;
                    $scope.entity.FlightSegment = res.Data.result.FlightSegment;
                    $scope.entity.PaxTotal = res.Data.result.PAXTotal;
                    $scope.entity.TypeRegisteration = res.Data.result.TypeRegisteration

                }

            });
        });

        qaService.getReferredList($scope.followUpEntity.EmployeeId, $scope.followUpEntity.Type, $scope.followUpEntity.Id).then(function (response) {
            $scope.referred_list_ds = response.Data;
        });

    };
    ////////////////////////////////
    $scope.scroll_qaCabin_height = $scope.popup_height - 115;
    $scope.scroll_qaCabin = {
        width: 900,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_qaCabin_height'
        }

    };

    $scope.scroll_referre_height = $scope.popup_height - 115;
    $scope.scroll_referre = {
        width: 590,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_referre_height'
        }

    };

    /////////////////////////////////









    $scope.chkFlightPhase = function (index) {
        $scope.flightPhase[index].checked = !$scope.flightPhase[index].checked;
        console.log($scope.fpoptions);
        $scope.entity.FlightPhaseId = $scope.flightPhase[index].Id;
    }

    $scope.chkEventTitle = function (index) {
        $scope.eventTitle[index].checked = !$scope.eventTitle[index].checked;

        $.each($scope.eventTitle, function (_i, _d) {
            if (_d.Title.includes('Other')) {
                if (_d.checked)
                    $scope.showOther = true;
                else
                    $scope.showOther = false;
            }
        });

        $scope.entity.EventTitleIds.push($scope.eventTitle[index].Id);

    }

    $scope.txt_repFieldBy = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.ReportFiledBy',
        }
    }

    $scope.txt_OccurrenceDate = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'yyyy-MM-dd HH:mm',
        type: 'datetime',
        bindingOptions: {
            value: 'entity.OccurrenceDateTime',
        }
    }
    //$scope.txt_apxTime = {
    //    hoverStateEnabled: false,
    //    type: 'time',
    //    displayFormat: 'HH:mm',
    //    bindingOptions: {
    //        value: 'entity.Time',
    //    }
    //}

    $scope.num_fltNum = {
        min: 0,
        bindingOptions: {
            value: 'entity.FlightNumber',
        }
    }

    $scope.txt_fltSeg = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.FlightSegment',
        }
    }

    $scope.txt_eventOther = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.EventTitleRemark',
        }
    }

    $scope.txt_eventLoc = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.EventLocation',
        }
    }

    $scope.txt_acType = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.TypeRegisteration',
        }
    }

    $scope.num_PAXNum = {
        min: 0,
        bindingOptions: {
            value: 'entity.PaxTotal',
        }
    }



    $scope.txt_desOccurrence = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Describtion',
        }
    }
    $scope.txt_Rec = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Recommendation',
        }
    }

    $scope.txt_wxCondition = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.WeatherCondition',
        }
    }

    $scope.num_refNumber = {
        min: 0,
        bindingOptions: {
            value: 'entity.RefNumber',
        }
    }

    $scope.txt_BOX = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.BOX',
        }
    }

    $scope.txt_Name = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Name',
        }
    }

    $scope.txt_recived = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Recived',
        }
    }

    $scope.txt_followup = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.FollowUp',
        }
    }


    ////////////////////////////////

    $scope.referred_list_columns = [
        { dataField: 'ReferredName', caption: 'Name', allowResizing: true, alignment: 'center', dataType: 'number', allowEditing: false, width: 350 },
        { dataField: 'DateStatus', caption: 'Date', allowResizing: true, alignment: 'center', dataType: 'date', allowEditing: false, width: 240 },
    ]
    $scope.referred_list = {
        keyExpr: 'ReferredId',
        parentIdExpr: 'ReferrerId',
        columns: $scope.referred_list_columns,
        noDataText: '',
        bindingOptions: {
            dataSource: 'referred_list_ds',

        }
    }

    ////////////////////////////////


    $scope.$on('InitQACabin', function (event, prms) {


        $scope.tempData = null;

        $scope.tempData = prms;
        $scope.followUpEntity.Category = $scope.tempData.Category;
        $scope.followUpEntity.Id = $scope.tempData.Id;
        $scope.followUpEntity.Type = $scope.tempData.Type;
        $scope.followUpEntity.EmployeeId = $scope.tempData.EmployeeId;
        $scope.isNotDetermined = $scope.tempData.isNotDetermined;

        if ($scope.tempData.Status != null)
            $scope.isSettled = false
        $scope.popup_add_visible = true;

    });



}]);

