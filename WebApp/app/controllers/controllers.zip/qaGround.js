﻿'use strict';
app.controller('qaGroundController', ['$scope', '$location', 'qaService', 'authService', '$routeParams', '$rootScope', '$window', function ($scope, $location, qaService, authService, $routeParams, $rootScope, $window) {
    $scope.isFullScreen = false;

    $scope.entity = {
        Id: -1,
        Type: 1,
    };

    $scope.followUpEntity = {
        Type: 1,
    }

    $scope.dmgOptions = [];
    $scope.wxOptions = [];
    $scope.surfaceOptions = [];
    $scope.lightingOptions = [];


    ////////////////////////
    $scope.popup_add_visible = false;
    $scope.popup_height = $(window).height() - 100;
    $scope.popup_width = 1500;
    $scope.popup_add_title = 'Ground Incident/Accident/Damage';
    $scope.popup_instance = null;

    $scope.popup_add = {


        showTitle: true,

        toolbarItems: [

            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Referre', onClick: function (e) {

                        $rootScope.$broadcast('InitQAEmployee', { Type: $scope.followUpEntity.Type, Id: $scope.tempData.Id });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'default', text: 'Action', onClick: function (e) {

                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'success', text: 'Accept', onClick: function (e) {
                        $scope.loadingVisible = true;

                        console.log("Is Responsible",$scope.isResponsible);

                        if ($scope.isResponsible == true) {
                            $scope.entity.Status = 1;
                            $scope.entity.StatusEmployeeId = $scope.followUpEntity.EmployeeId;
                            qaService.saveGIA($scope.entity).then(function (response) {
                                console.log(response.Data);
                            });

                        }


                        qaService.acceptQA($scope.followUpEntity).then(function (response) {
                            if (response.IsSuccess == true) {
                                General.ShowNotify(Config.Text_QAAccept, 'success');

                                if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                    $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                    $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                        return x.Id != $scope.entity.Id;
                                    }).ToArray();

                                }

                                if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                    $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                    $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                        return x.Id != $scope.entity.Id;
                                    }).ToArray();

                                }
                                $scope.loadingVisible = false;
                            }
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'before', options: {
                    type: 'danger', text: 'Reject', onClick: function (e) {
                        $scope.loadingVisible = true;
                        qaService.rejectQA($scope.followUpEntity).then(function (response) {
                            General.ShowNotify(Config.Text_QAAccept, 'success');

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'open') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_open_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_open_ds = Enumerable.From($rootScope.dg_open_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }

                            if (response.IsSuccess == true && $scope.followUpEntity.Category == 'new') {
                                $rootScope.dg_determined_ds = Enumerable.From($rootScope.dg_new_ds).Where("$.Id==" + $scope.entity.Id).ToArray();
                                $rootScope.dg_new_ds = Enumerable.From($rootScope.dg_new_ds).Where(function (x) {
                                    return x.Id != $scope.entity.Id;
                                }).ToArray();

                            }
                            $scope.loadingVisible = false;
                        });
                    }
                }, toolbar: 'bottom'
            },
            {
                widget: 'dxButton', location: 'after', options: {
                    type: 'danger', text: 'Close', icon: 'remove', onClick: function (e) {
                        $scope.popup_add_visible = false;
                        $scope.dmgOptions = [];
                        $scope.wxOptions = [];
                        $scope.surfaceOptions = [];
                        $scope.lightingOptions = [];
                    }
                }, toolbar: 'bottom'
            }
        ],

        visible: false,
        dragEnabled: true,
        closeOnOutsideClick: false,
        onShowing: function (e) {
            $rootScope.IsRootSyncEnabled = false;
            $scope.popup_instance.repaint();


        },
        onShown: function (e) {
            if ($scope.tempData != null)
                $scope.bind();





        },
        onHiding: function () {
            $rootScope.IsRootSyncEnabled = true;
            //$scope.clearEntity();
            $scope.entity = {
                Id: -1,
            };

            $scope.referred_list_ds = null;

            $scope.popup_add_visible = false;
            $rootScope.$broadcast('onGRFHide', null);
        },
        onContentReady: function (e) {
            if (!$scope.popup_instance)
                $scope.popup_instance = e.component;

        },
        // fullScreen:false,
        bindingOptions: {
            visible: 'popup_add_visible',
            fullScreen: 'isFullScreen',
            title: 'popup_add_title',
            height: 'popup_height',
            width: 'popup_width',
            'toolbarItems[0].visible': 'isSettled',
            'toolbarItems[1].visible': 'isSettled',
            'toolbarItems[2].visible': 'isSettled',
            'toolbarItems[3].visible': 'isSettled',

        }
    };



    /////////////////////////////////



    $scope.flight = null;
    $scope.fill = function (data) {
        $scope.entity = data;

        $.each($scope.damageBy, function (_i, _d) {
            if (_d.Title.includes('Other')) {
                if (_d.checked)
                    $scope.showOther = true;
                else
                    $scope.showOther = false;
            }
        });

        $scope.dmgOptions[data.DamageById] = true;
        $scope.wxOptions[data.WXWeatherId] = true;
        $scope.surfaceOptions[data.WXSurfaceId] = true;
        $scope.lightingOptions[data.WXLightingId] = true;
    };


    $scope.bind = function () {

        qaService.getDamageBy().then(function (res) {
            $scope.damageBy = res.Data;
        });

        qaService.getSurface().then(function (res) {
            $scope.surface = res.Data;
        });

        qaService.getWeather().then(function (res) {
            $scope.weather = res.Data;
        });

        qaService.getLighting().then(function (res) {
            $scope.lighting = res.Data;
            qaService.getGIAById($scope.followUpEntity.Id).then(function (res) {
                $scope.fill(res.Data);
            });
        });

        qaService.getReferredList($scope.followUpEntity.EmployeeId, $scope.followUpEntity.Type, $scope.followUpEntity.Id).then(function (response) {
            $scope.referred_list_ds = response.Data;
        });

        qaService.getIsResponsible($scope.followUpEntity.EmployeeId, $scope.followUpEntity.Type, $scope.followUpEntity.Id).then(function (response) {
            if (response.IsSuccess == true)
                $scope.isResponsible = true

        });




    };
    ////////////////////////////////
    $scope.scroll_qaGround_height = $scope.popup_height - 115;
    $scope.scroll_qaGround = {
        width: 900,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_qaGround_height'
        }

    };


    $scope.scroll_referre_height = $scope.popup_height - 115;
    $scope.scroll_referre = {
        width: 590,
        bounceEnabled: false,
        showScrollbar: 'never',
        pulledDownText: '',
        pullingDownText: '',
        useNative: true,
        refreshingText: 'Updating...',
        onPullDown: function (options) {

            options.component.release();

        },
        onInitialized: function (e) {


        },
        bindingOptions: {
            height: 'scroll_referre_height'
        }

    };

    /////////////////////////////////




    $scope.chkDamageBy = function (index) {

        $.each($scope.damageBy, function (_i, _d) {
            if (_d.Title.includes('Other')) {
                if (_d.checked)
                    $scope.showOther = true;
                else
                    $scope.showOther = false;
            }
        });

        $scope.damageBy[index].checked = !$scope.damageBy[index].checked;
        $scope.entity.DamageById = $scope.damageBy[index].Id;

    }

    $scope.chkLighting = function (index) {
        $scope.lighting[index].checked = !$scope.lighting[index].checked;
        $scope.entity.WXLightingId = $scope.lighting[index].Id;
    }

    $scope.chkWeather = function (index) {
        $scope.weather[index].checked = !$scope.weather[index].checked;
        $scope.entity.WXWeatherId = $scope.weather[index].Id;
    }

    $scope.chkSurface = function (index) {
        $scope.surface[index].checked = !$scope.surface[index].checked;
        $scope.entity.WXSurfaceId = $scope.surface[index].Id;
    }



    $scope.txt_date = {
        hoverStateEnabled: false,
        useMaskBehavior: true,
        displayFormat: 'yyyy-MM-dd HH:mm',
        type: 'datetime',
        bindingOptions: {
            value: 'entity.DamageDate',
        }
    }

    $scope.txt_optPhase = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OperationPhase',
        }
    }

    $scope.txt_occurrecneTime = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OccurrenceTime',
        }
    }

    $scope.txt_area = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Area',
        }
    }

    $scope.txt_acRegister = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.Register',
        }
    }

    $scope.txt_acType = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.AircraftType',
        }
    }

    $scope.txt_fltNum = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.FlightNumber',
        }
    }

    $scope.txt_gndTime = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.ScheduledGroundTime',
        }
    }

    $scope.txt_fltDelay = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.FlightDelay',
        }
    }

    $scope.dsFlightCancelled = [
        { id: 0, title: 'NO' },
        { id: 1, title: 'YES' },
    ];

    $scope.sb_fltCancelled = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsFlightCancelled,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.flightCancelled',
        }
    }


    $scope.txt_damageDetail = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.DamageDetails',
        }
    }

    $scope.txt_eeCasualty = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.EmployeesFatalityNr',
        }
    }

    $scope.txt_eeNonCasualty = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.EmployeesNonFatalityNr',
        }
    }

    $scope.txt_paxCasualty = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.PassengersFatalityNr',
        }
    }

    $scope.txt_paxNonCasualty = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.PassengersNonFatalityNr',
        }
    }

    $scope.txt_otherCasualty = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OthersFatalityNr',
        }
    }

    $scope.txt_otherNonCasualty = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.OthersNonFatalityNr',
        }
    }

    $scope.txt_veFleetSerial = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VESerialFleetNr',
        }
    }

    $scope.txt_veType = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VEType',
        }
    }

    $scope.txt_veOwner = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VEOwner',
        }
    }

    $scope.txt_eqArea = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VEArea',
        }
    }

    $scope.txt_veAga = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VEAge',
        }
    }

    $scope.txt_veLastOverhaul = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VELastOverhaul',
        }
    }


    $scope.txt_veRemarks = {
        hoverStateEnabled: false,
        bindingOptions: {
            value: 'entity.VERemarks',
        }
    }




    $scope.dsVehicleDetail = [
        { id: 0, title: 'Serviceable' },
        { id: 1, title: 'Faulty' },
        { id: 2, title: 'Unknown' }
    ];

    $scope.sb_veTyer = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VETyresCon',
        }
    }

    $scope.sb_veBrake = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VEBrakesCon',
        }
    }



    $scope.sb_veSteering = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VESteeringCon',
        }
    }



    $scope.sb_veLight = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VELightsCon',
        }
    }



    $scope.sb_veWiper = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VEWipersCon',
        }
    }



    $scope.sb_veProtection = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VEProtectionCon',
        }
    }



    $scope.sb_veWarningDevices = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VEWarningDevicesCon',
        }
    }

    $scope.sb_veStab = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VEStabilizersCon',
        }
    }


    $scope.sb_veTow = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VETowHitchCon',
        }
    }


    $scope.sb_veVision = {
        showClearButton: true,
        searchEnabled: false,
        dataSource: $scope.dsVehicleDetail,
        placeholder: '',
        displayExpr: 'title',
        valueExpr: 'id',
        bindingOptions: {
            value: 'entity.VEFieldofVisionCon',
        }
    }


    $scope.txt_eventOther = {
        bindingOptions: {
            value: 'entity.DamageRemark',
        }
    }

    $scope.txt_p1Name = {
        bindingOptions: {
            value: 'entity.PersonnelName1',
        }
    }

    $scope.txt_p1Job = {
        bindingOptions: {
            value: 'entity.PersonnelJobTitle1',
        }
    }

    $scope.txt_p1Compony = {
        bindingOptions: {
            value: 'entity.PersonnelCompany1',
        }
    }

    $scope.txt_p1StaffNum = {
        bindingOptions: {
            value: 'entity.PersonnelStaffNr1',
        }
    }

    $scope.txt_p1License = {
        bindingOptions: {
            value: 'entity.PersonnelLicense1',
        }
    }



    $scope.txt_p2Name = {
        bindingOptions: {
            value: 'entity.PersonnelName2',
        }
    }

    $scope.txt_p2Job = {
        bindingOptions: {
            value: 'entity.PersonnelJobTitle2',
        }
    }

    $scope.txt_p2Compony = {
        bindingOptions: {
            value: 'entity.PersonnelCompany2',
        }
    }

    $scope.txt_p2StaffNum = {
        bindingOptions: {
            value: 'entity.PersonnelStaffNr2',
        }
    }

    $scope.txt_p2License = {
        bindingOptions: {
            value: 'entity.PersonnelLicense2',
        }
    }

    $scope.txt_p3Name = {
        bindingOptions: {
            value: 'entity.PersonnelName3',
        }
    }

    $scope.txt_p3Job = {
        bindingOptions: {
            value: 'entity.PersonnelJobTitle3',
        }
    }

    $scope.txt_p3Compony = {
        bindingOptions: {
            value: 'entity.PersonnelCompany3',
        }
    }

    $scope.txt_p3StaffNum = {
        bindingOptions: {
            value: 'entity.PersonnelStaffNr3',
        }
    }

    $scope.txt_p3License = {
        bindingOptions: {
            value: 'entity.PersonnelLicense3',
        }
    }

    $scope.txt_VISByMeter = {
        bindingOptions: {
            value: 'entity.WXVisibilityM',
        }
    }

    $scope.txt_VISByKiloMeter = {
        bindingOptions: {
            value: 'entity.WXVisibilityKM',
        }
    }


    $scope.txt_wind = {
        bindingOptions: {
            value: 'entity.WXWind',
        }
    }

    $scope.txt_temp = {
        bindingOptions: {
            value: 'entity.WXTemperature',
        }
    }

    $scope.txt_contributFact = {
        bindingOptions: {
            value: 'entity.ContributoryFactors',
        }
    }

    //$scope.sketch = {
    //    bindingOptions: {
    //        value: 'entity.sketch',
    //    }
    //}

    $scope.txt_Event = {
        bindingOptions: {
            value: 'entity.Event',
        }
    }

    $scope.txt_correctiveAction = {
        bindingOptions: {
            value: 'entity.CorrectiveActionTaken',
        }
    }

    $scope.txt_otherRMK = {
        bindingOptions: {
            value: 'entity.OtherSuggestions',
        }
    }


    ////////////////////////////
    $scope.referred_list_columns = [
        { dataField: 'ReferredName', caption: 'Name', allowResizing: true, alignment: 'center', dataType: 'number', allowEditing: false, width: 350 },
        { dataField: 'DateStatus', caption: 'Date', allowResizing: true, alignment: 'center', dataType: 'date', allowEditing: false, width: 240 },
    ]
    $scope.referred_list = {
        keyExpr: 'ReferredId',
        parentIdExpr: 'ReferrerId',
        columns: $scope.referred_list_columns,
        noDataText: '',
        bindingOptions: {
            dataSource: 'referred_list_ds',

        }
    }

    ////////////////////////////////

    $scope.tempData = null;

    $scope.$on('InitQAGround', function (event, prms) {


        $scope.tempData = null;




        $scope.tempData = prms;
        $scope.followUpEntity.Category = $scope.tempData.Category;
        $scope.followUpEntity.Id = $scope.tempData.Id;
        $scope.followUpEntity.Type = $scope.tempData.Type;
        $scope.followUpEntity.EmployeeId = $scope.tempData.EmployeeId;
        $scope.isNotDetermined = $scope.tempData.isNotDetermined;
        if ($scope.tempData.Status != null)
            $scope.isSettled = false
        $scope.popup_add_visible = true;

    });



}]);


